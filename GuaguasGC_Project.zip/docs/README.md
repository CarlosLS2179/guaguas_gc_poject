
# Guaguas GC

Aplicación para trackeo en tiempo real de guaguas (autobuses) de Gran Canaria.

## Componentes

- Backend: FastAPI con base de datos PostgreSQL + PostGIS
- Frontend móvil: Android (Kotlin + Google Maps SDK)
- Notificaciones: vía Firebase o correo electrónico (opcional)

## Cómo ejecutar

1. Backend:
    ```
    cd backend
    pip install -r requirements.txt
    uvicorn main:app --reload
    ```

2. App Android:
    - Abrir el proyecto con Android Studio

## API básica

- `GET /api/stops/{stop_id}/arrivals`  
  Devuelve las próximas guaguas por parada (simulado)

Más endpoints estarán disponibles en versiones futuras.
