
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Enable CORS for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/stops/{stop_id}/arrivals")
async def get_arrivals(stop_id: int):
    return {"stop_id": stop_id, "next_buses": ["Línea 1 - 5 min", "Línea 3 - 12 min"]}
